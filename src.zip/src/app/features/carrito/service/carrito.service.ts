import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { Carrito, DetalleCarrito, AgregarAlCarrito} from '../../../models/carrito.model';
import { ApiResponse } from '../../../models/api-response.model';
import { environment } from '../../../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class CarritoService {
  
  private apiUrl = `${environment.apiUrl}/api/v1/carrito`;

  private carritoSubjetc = new BehaviorSubject<Carrito | null>(null);
  public carrito$ = this.carritoSubjetc.asObservable();

  constructor(private http: HttpClient) {}

  obtenerCarrito(usuarioId: number): Observable<ApiResponse<Carrito>> {
    return this.http.get<ApiResponse<Carrito>>(`${this.apiUrl}/${usuarioId}`);
  }

  agregarProducto(usuarioId:number, request:AgregarAlCarrito):Observable<ApiResponse<Carrito>>{
    return this.http.post<ApiResponse<Carrito>>(`${this.apiUrl}/${usuarioId}/agregar`, request).pipe(
      tap(response =>{
        if(response.data){
          this.carritoSubjetc.next(response.data)
        }
      })
    );
  }

  eliminarProducto(detalleId:number, carritoId:number):Observable<void>{
    return this.http.delete<void>(`${this.apiUrl}/detalle/${detalleId}?carritoId=${carritoId}`)
  }
  

  varciarCarrito(carritoId:number):Observable<void>{
    return this.http.delete<void>(`${this.apiUrl}/${carritoId}/vaciar`);
  }

  enviarWhatsapp(carritoId:number):Observable<ApiResponse<Carrito>>{
    return this.http.post<ApiResponse<Carrito>>(`${this.apiUrl}/${carritoId}/enviar-whatsapp`,{});
  }

  obtenerCantidadProductos(carrito:Carrito):number{
    if(!carrito || !carrito.detalles){
      return 0;
    }
    return carrito.detalles.reduce((total, detalle)=> total + detalle.cantidad, 0)
  }

  obtenerTotal(carrito:Carrito):number{
    if(!carrito || !carrito.detalles){
      return 0;
    }
    return carrito.detalles.reduce((total, detalle)=> total + detalle.subtotal, 0)
  }

  actualizarCantidad(detalleId: number, carritoId: number, cantidad: number):Observable<ApiResponse<Carrito>>{
    return this.http.put<ApiResponse<Carrito>>(
         `${this.apiUrl}/detalle/${detalleId}?cantidad=${cantidad}&carritoId=${carritoId}`, {}
    ).pipe(
      tap((response: ApiResponse<Carrito>)=>{
        if(response.data){
          this.carritoSubjetc.next(response.data)
        }
      })
    )
  }

  actualizarBehaviorSubject(carrito: Carrito): void{
    this.carritoSubjetc.next({... carrito, detalles: [...carrito.detalles]});
  }

  generarURLWhatsapp(carrito:Carrito, numeroEmpresa: string = '51973306855'):string{
    let mensaje = '*Mi carrito de compras*\n\n';

    if(carrito.detalles && carrito.detalles.length > 0){
      carrito.detalles.forEach((detalle, index)=>{
        
        //puede venir producto o de presentacion
        const nombre = 
        detalle.producto?.nombre || 
        detalle.presentacion?.nombreProducto || 
        'Producto';

        //detalle extra si tiene presentacion
        const extra = detalle.presentacion 
        ? `Presentacion: 
        ${detalle.presentacion.tipoPresentacion || ''} 
        ${detalle.presentacion.cantidadBase} 
        ${detalle.presentacion.tipoUnidad || ''}\n` : '';



        mensaje += `${index + 1}. ${nombre}\n`;
        mensaje += extra;
        mensaje += `   Cantidad: ${detalle.cantidad}\n`;
        mensaje += `   Precio Unitario: S/ ${detalle.precioUnitario.toFixed(2)}\n`;
        if(detalle.descuento >0){
          mensaje += `Descuento: ${detalle.descuento}%\n`;

        }
        mensaje += `Subtotal: S/ ${detalle.subtotal.toFixed(2)}\n\n`;
      })
    }
    const total = this.obtenerTotal(carrito);
    mensaje += `*Total: S/ ${total.toFixed(2)}*\n`;
    mensaje += '\nPor favor confirmar mi pedido';

    const urlWhtatsapp = `https://wa.me/${numeroEmpresa}?text=${encodeURIComponent(mensaje)}`;
    return urlWhtatsapp;
  }
}
